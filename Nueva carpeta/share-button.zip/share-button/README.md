# Share Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/thelaazyguy/pen/WEjRgw](https://codepen.io/thelaazyguy/pen/WEjRgw).

Share button animation using font awesome, css and some jquery.